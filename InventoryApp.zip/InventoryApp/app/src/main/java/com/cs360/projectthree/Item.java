package com.cs360.projectthree;

public class Item {
    private int mId;
    private String mName;
    private int mQuantity;
    private String mUnitOfMeasure;
    private String mUser;

    public Item() {}

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        this.mId = id;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        this.mName = name;
    }

    public int getQuantity() {
        return mQuantity;
    }

    public void setQuantity(int quantity) {
        this.mQuantity = quantity;
    }

    public String getUnitOfMeasure() {
        return mUnitOfMeasure;
    }

    public void setUnitOfMeasure(String unitOfMeasure) {
        this.mUnitOfMeasure = unitOfMeasure;
    }

    public String getUser() {
        return mUser;
    }

    public void setUser(String user) {
        this.mUser = user;
    }
}
