package com.cs360.projectthree;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;

public class ApplicationDatabase extends SQLiteOpenHelper {
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "application.db";

    private static ApplicationDatabase mAppDb;

    public static ApplicationDatabase getInstance(Context context) {
        if (mAppDb == null) {
            mAppDb = new ApplicationDatabase(context);
        }
        return mAppDb;
    }

    private ApplicationDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }
    // Table for users
    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }
    // Table for items
    private static final class ItemTable {
        private static final String TABLE = "items";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_QUANTITY = "quantity";
        private static final String COL_UOM = "UOM";
        private static final String COL_USER = "user";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        db.execSQL("create table " + UserTable.TABLE + " (" +
                // Primary key is username, will prevent duplicates
                UserTable.COL_USERNAME + " primary key, " +
                UserTable.COL_PASSWORD + " text)");
        // Create items table
        db.execSQL("create table " + ItemTable.TABLE + " (" +
                ItemTable.COL_ID + " integer primary key autoincrement, " +
                ItemTable.COL_NAME + " text, " +
                ItemTable.COL_QUANTITY + " int, " +
                ItemTable.COL_UOM + " text, " +
                ItemTable.COL_USER + " text, " +
                // Create foreign key with item's user column to user's username column
                // On cascade delete to delete all items associated with user if user is deleted
                "foreign key(" + ItemTable.COL_USER + ") references " +
                UserTable.TABLE + "(" + UserTable.COL_USERNAME + ") on delete cascade)");
    }

    /*
     * Drop then recreate the tables upon upgrade
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        db.execSQL("drop table if exists " + ItemTable.TABLE);
        onCreate(db);
    }

    /*
     * Enable foreign key constraints
     */
    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                db.execSQL("pragma foreign_keys = on;");
            } else {
                db.setForeignKeyConstraintsEnabled(true);
            }
        }
    }

    /*
     * Add a new user to the database
     */
    public boolean addUser(User user) {
        // Get writeable SQLiteDatabase object
        SQLiteDatabase db = getWritableDatabase();
        // Create ContentValues object to hold table columns and data to insert
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, user.getUsername());
        values.put(UserTable.COL_PASSWORD, user.getPassword());
        long id = db.insert(UserTable.TABLE, null, values);
        return id != -1;
    }

    /*
     * Check if a given username exists and if so, check if a given password matches
     */
    public boolean findUser(String username, String password) {
        // Get SQLiteDatabase object that can be queried
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + UserTable.TABLE + " where username = ? and password = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {username, password});
        // If user and password match is found
        if (cursor.moveToFirst()) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;
    }

    /*
     * Add a new item to the database
     */
    public boolean addItem(Item item) {
        // Get writeable SQLiteDatabase object
        SQLiteDatabase db = getWritableDatabase();
        // Create ContentValues object to hold table columns and data to insert
        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_NAME, item.getName());
        values.put(ItemTable.COL_QUANTITY, item.getQuantity());
        values.put(ItemTable.COL_UOM, item.getUnitOfMeasure());
        values.put(ItemTable.COL_USER, item.getUser());
        long id = db.insert(ItemTable.TABLE, null, values);
        return id != -1;
    }

    /*
     * Update an item in the database
     */
    public void updateItem(Item item) {
        // Get writeable SQLiteDatabase object
        SQLiteDatabase db = getWritableDatabase();
        // Create ContentValues object to hold table columns and data to insert
        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_ID, item.getId());
        values.put(ItemTable.COL_NAME, item.getName());
        values.put(ItemTable.COL_QUANTITY, item.getQuantity());
        values.put(ItemTable.COL_UOM, item.getUnitOfMeasure());
        values.put(ItemTable.COL_USER, item.getUser());
        db.update(ItemTable.TABLE, values, ItemTable.COL_ID + " = " + item.getId(), null);
    }

    /*
     * Delete an item from the database
     */
    public void deleteItem(int itemId) {
        // Get writeable SQLiteDatabase object
        SQLiteDatabase db = getWritableDatabase();
        db.delete(ItemTable.TABLE,ItemTable.COL_ID + " = " + itemId, null);
    }

    /*
     * Get an item from the database
     */
    public Item getItem(int itemId) {
        Item item = null;

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + ItemTable.TABLE +
                " where " + ItemTable.COL_ID + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { String.valueOf(itemId) });
        if (cursor.moveToFirst()) {
            item = new Item();
            item.setId(cursor.getInt(0));
            item.setName(cursor.getString(1));
            item.setQuantity(cursor.getInt(2));
            item.setUnitOfMeasure(cursor.getString(3));
            item.setUser(cursor.getString(4));
        }
        cursor.close();
        return item;
    }

    /*
     * Get all items from the database
     */
    public List<Item> getItems(String user) {
        List<Item> items = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + ItemTable.TABLE +
                " where " + ItemTable.COL_USER + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {user});
        if (cursor.moveToFirst()) {
            do {
                Item item = new Item();
                item.setId(cursor.getInt(0));
                item.setName(cursor.getString(1));
                item.setQuantity(cursor.getInt(2));
                item.setUnitOfMeasure(cursor.getString(3));
                item.setUser(cursor.getString(4));
                items.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return items;
    }
}
