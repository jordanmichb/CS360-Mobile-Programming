package com.cs360.projectthree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private ApplicationDatabase mUserDb;
    private EditText usernameEditText;
    private EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Get database
        mUserDb = ApplicationDatabase.getInstance(getApplicationContext());
        // Get views
        usernameEditText = findViewById(R.id.login_username);
        passwordEditText = findViewById(R.id.login_password);

        // Clear fields
        usernameEditText.setText("");
        passwordEditText.setText("");
    }

    /*
     * Button callback for login button. This will take the values from
     * the username and password fields and use these to search for the
     * user. If both values match the information in the database then
     * the user will be logged in.
     */
    public void onLoginClicked(View view) {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // If user exists and information matches
        if (mUserDb.findUser(username, password)) {
            // Log in
            Intent intent = new Intent(this, ListActivity.class);
            // Pass the user to list activity so they can view their own items only
            intent.putExtra(ListActivity.EXTRA_USER, username);
            startActivity(intent);
        }
        else {
            Toast.makeText(this, "Incorrect username or password.", Toast.LENGTH_SHORT).show();
        }
    }

    /*
     * Button callback for new user button. This will take the values from
     * the username and password fields and use these to create a new user.
     * If the username is already being used, the user will not be added.
     */
    public void onAddUserClicked(View view) {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        User user = new User(username, password);
        if (mUserDb.addUser(user)) {
            Toast.makeText(this, "New user added.", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "Username already in use.", Toast.LENGTH_SHORT).show();
        }
    }
}