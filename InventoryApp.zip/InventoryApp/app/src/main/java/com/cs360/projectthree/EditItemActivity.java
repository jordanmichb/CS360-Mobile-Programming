package com.cs360.projectthree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class EditItemActivity extends AppCompatActivity {
    public static final String EXTRA_ITEM_ID = "com.cs360.projectthree.item_id";

    private TextView mItemNameTextView;
    private EditText mItemQuantityEditText;
    private EditText mItemUOMEditText;

    private Item mItem;
    private int mId;
    private String mName;
    private int mQuantity;
    private String mUnitOfMeasure;

    private ApplicationDatabase mAppDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        // Get singleton
        mAppDb = ApplicationDatabase.getInstance(getApplicationContext());
        // Get views
        mItemNameTextView = findViewById(R.id.nameTitle);
        mItemQuantityEditText = findViewById(R.id.itemQuantity);
        mItemUOMEditText = findViewById(R.id.itemUOM);

        // Get id extra from intent
        Intent intent = getIntent();
        mId = intent.getIntExtra(EXTRA_ITEM_ID, 0);
        // Use the id to retrieve the item from database
        mItem = mAppDb.getItem(mId);

        // Get item details
        mName = mItem.getName();
        mQuantity = mItem.getQuantity();
        mUnitOfMeasure = mItem.getUnitOfMeasure();
        // Set view text with item details
        mItemNameTextView.setText(mName);
        mItemQuantityEditText.setText(String.valueOf(mQuantity));
        mItemUOMEditText.setText(mUnitOfMeasure);
    }

    /*
     * Button callback for the increment button. This increments
     * the current value inside EditText.
     */
    public void onIncreaseClicked(View view) {
        mQuantity = Integer.parseInt(mItemQuantityEditText.getText().toString());
        mQuantity++;
        mItemQuantityEditText.setText(String.valueOf(mQuantity));
    }

    /*
     * Button callback for the decrement button. This decrements
     * the current value inside EditText.
     */
    public void onDecreaseClicked(View view) {
        mQuantity = Integer.parseInt(mItemQuantityEditText.getText().toString());
        mQuantity--;
        mItemQuantityEditText.setText(String.valueOf(mQuantity));
    }

    /*
     * Button callback for the save button. This takes all EditText
     * values and updates the item in the database. Then ListActivity
     * is immediately started.
     */
    public void onSaveClicked(View view) {
        // Get EditText values
        mQuantity = Integer.parseInt(mItemQuantityEditText.getText().toString());
        mUnitOfMeasure = mItemUOMEditText.getText().toString();

        // Set item details
        mItem.setQuantity(mQuantity);
        mItem.setUnitOfMeasure(mUnitOfMeasure);
        // Update the item in the database
        mAppDb.updateItem(mItem);

        // If quantity has reached 0 and the app has SMS permission, send notification
        if (mQuantity == 0 && SettingsFragment.sendSMSSwitch.isChecked()
                && PermissionsUtil.hasPermission(this, android.Manifest.permission.SEND_SMS)) {
            sendSMS();
        }

        // Start list activity and pass the user back
        Intent intent = new Intent(this, ListActivity.class);
        intent.putExtra(ListActivity.EXTRA_USER, mItem.getUser());
        startActivity(intent);
    }

    /*
     * Send an SMS message to the device.
     */
    private void sendSMS() {
        // Construct message with item name
        String message = getResources().getString(R.string.zero_inventory_sms, mItem.getName());
        // Get device ID
        String android_id = Settings.Secure.getString(EditItemActivity.this.getContentResolver(),
                                                      Settings.Secure.ANDROID_ID);

        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(android_id, null, message, null, null);
    }

    /*
     * Load the menu resource for the delete button in the app bar.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.edit_item_menu, menu);
        return true;
    }

    /*
     * Start settings activity when the button is selected.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.delete:
                mAppDb.deleteItem(mId);
                Toast.makeText(this, mName + " deleted.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, ListActivity.class);
                intent.putExtra(ListActivity.EXTRA_USER, mItem.getUser());
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}