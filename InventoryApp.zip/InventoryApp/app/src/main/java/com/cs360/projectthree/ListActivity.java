package com.cs360.projectthree;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

public class ListActivity extends AppCompatActivity {
    public static final String EXTRA_USER = "com.cs360.projectthree.user";

    private String mUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        // Get the fragment
        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.list_fragment_container);

        // If null, begin a new FragmentTransaction and add the fragment to the container
        if (fragment == null) {
            fragment = new ListFragment();
            fragmentManager.beginTransaction().add(R.id.list_fragment_container, fragment).commit();
        }

        // Get user extra from intent
        Intent intent = getIntent();
        mUser = intent.getStringExtra(EXTRA_USER);
    }

    /*
     * Button callback for the add button. This starts AddActivity
     * where new items can be added to the database.
     */
    public void onAddItemClicked(View view) {
        Intent intent = new Intent(this, AddItemActivity.class);
        // Pass the user to AddActivity
        intent.putExtra(AddItemActivity.EXTRA_USER, mUser);
        startActivity(intent);
    }

    /*
     * Load the menu resource for the settings in the app bar.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.list_menu, menu);
        return true;
    }

    /*
     * Start settings activity when the button is selected.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        Intent intent;
        switch (item.getItemId()) {
            case R.id.settings:
                intent = new Intent(ListActivity.this, SettingsActivity.class);
                intent.putExtra(SettingsActivity.EXTRA_USER, mUser);
                startActivity(intent);
                return true;
            case R.id.sign_out:
                intent = new Intent(ListActivity.this, LoginActivity.class);
                startActivity(intent);
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}