package com.cs360.projectthree;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ListFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_list, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.item_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        // Send items to recycler view
        String user = getActivity().getIntent().getStringExtra(ListActivity.EXTRA_USER);
        ItemAdapter adapter = new ItemAdapter(ApplicationDatabase.getInstance(getContext()).getItems(user));
        recyclerView.setAdapter(adapter);

        // Place divider between fragments
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(),
                DividerItemDecoration.VERTICAL);
        recyclerView.addItemDecoration(dividerItemDecoration);

        return view;
    }

    /*
     * Inflates the list_component_item.xml layout file in the ItemHolder
     * constructor. the bind() method is called by ItemAdapter to bind the
     * item details to the TextView defined in the layout file.
     */
    private class ItemHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {

        private Item mItem;

        private TextView mNameTextView;
        private TextView mQuantityTextView;
        private TextView mUOMTextView;


        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_component_item, parent, false));
            itemView.setOnClickListener(this);
            mNameTextView = itemView.findViewById(R.id.itemName);
            mQuantityTextView = itemView.findViewById(R.id.itemQuantity);
            mUOMTextView = itemView.findViewById(R.id.itemUOM);
        }

        public void bind(Item item) {
            mItem = item;
            mNameTextView.setText(mItem.getName());
            mQuantityTextView.setText(String.valueOf(mItem.getQuantity()));
            mUOMTextView.setText(mItem.getUnitOfMeasure());
        }

        @Override
        public void onClick(View view) {
            Intent intent = new Intent(getActivity(), EditItemActivity.class);
            intent.putExtra(EditItemActivity.EXTRA_ITEM_ID, mItem.getId());
            startActivity(intent);
        }
    }

    /*
     * Instantiated by ListFragment using all the items from ItemDatabase.
     * The onCreateViewHolder() callback creates a new ItemHolder, which is
     * used in the onBindViewHolder() callback to display the item at the
     * given position when the RecycleView decides an item is about to be
     * scrolled onto the screen.
     */
    private class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {

        private List<Item> mItems;

        public ItemAdapter(List<Item> items) {
            mItems = items;
        }

        @Override
        public ItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new ItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(ItemHolder holder, int position) {
            Item item = mItems.get(position);
            holder.bind(item);
        }

        @Override
        public int getItemCount() {
            return mItems.size();
        }
    }
}