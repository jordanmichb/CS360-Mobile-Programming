package com.cs360.projectthree;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.SwitchPreference;

public class SettingsFragment extends PreferenceFragment implements SharedPreferences.OnSharedPreferenceChangeListener {
    private final int REQUEST_WRITE_CODE = 0;

    public static SwitchPreference sendSMSSwitch;
    private static SharedPreferences.Editor editor;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Load the preferences from an XML resource
        addPreferencesFromResource(R.xml.preferences);
        // Get switch
        sendSMSSwitch = (SwitchPreference) findPreference("pref_sms");

        // Access the shared prefs
        String user = getActivity().getIntent().getStringExtra(SettingsActivity.EXTRA_USER);
        SharedPreferences sharedPrefs = getActivity().getSharedPreferences(user, Context.MODE_PRIVATE);
        editor = sharedPrefs.edit();
        // Set switch based on prefs
        setSwitch(sharedPrefs);
    }

    /*
     * Checks value of permission request so that denials can be handled properly.
     */
    public static void setSwitchRequestResult(int[] grantResults) {
        if (!(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
            sendSMSSwitch.setChecked(false);
            editor.putBoolean("pref_sms", false).apply();
        }
    }

    /*
     * Set the switch based on permissions and user preferences.
     */
    private void setSwitch(SharedPreferences sharedPrefs) {
        // This is to see if permission has been revoked through the Settings app
        if (!(PermissionsUtil.hasPermission(getActivity(), android.Manifest.permission.SEND_SMS))) {
            sendSMSSwitch.setChecked(false);
            editor.putBoolean("pref_sms", false).apply();
        }
        else {
            boolean checked = sharedPrefs.getBoolean("pref_sms", false);
            sendSMSSwitch.setChecked(checked);
        }
    }

    // Action when preference is changed
    @Override
    public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
        boolean sendSMS = prefs.getBoolean(key, false);
        // If switch is on
        if (sendSMS) {
            editor.putBoolean("pref_sms", true).apply();
            // Request permissions
            PermissionsUtil.askPermission(getActivity(), android.Manifest.permission.SEND_SMS,
                    R.string.sms_rationale, REQUEST_WRITE_CODE);
        }
        else {
            editor.putBoolean("pref_sms", false).apply();
        }
    }

    // Register listener
    @Override
    public void onStart() {
        super.onStart();
        PreferenceManager.getDefaultSharedPreferences(getActivity())
                .registerOnSharedPreferenceChangeListener(this);
    }

    // Unregister listener
    @Override
    public void onStop() {
        super.onStop();
        PreferenceManager.getDefaultSharedPreferences(getActivity())
                .unregisterOnSharedPreferenceChangeListener(this);
    }
}