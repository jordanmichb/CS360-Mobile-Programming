package com.cs360.projectthree;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.pm.PackageManager;

import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class PermissionsUtil {
    /*
     * Check if the user has granted permissions. If not, ask for permission.
     */
    public static void askPermission(final Activity activity, final String permission,
                                         int rationaleMessageId, final int requestCode) {
        // See if permission is granted
        if (ContextCompat.checkSelfPermission(activity, permission) != PackageManager.PERMISSION_GRANTED) {
            // Explain why permission needed?
            if (ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)) {
                // Show why permission is needed
                showPermissionRationaleDialog(activity, rationaleMessageId, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Request permission again
                        ActivityCompat.requestPermissions(activity,
                                new String[] { permission }, requestCode);
                    }
                });
            }
            else {
                // Request permission
                ActivityCompat.requestPermissions(activity, new String[] { permission }, requestCode);
            }
        }
    }

    /*
     * Check whether or not the user has granted permission
     */
    public static boolean hasPermission(final Activity activity, final String permission) {
        if (ContextCompat.checkSelfPermission(activity, permission) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        return true;
    }

    /*
     * Show permission rationale
     */
    private static void showPermissionRationaleDialog(Activity activity, int messageId,
                                                      DialogInterface.OnClickListener onClickListener) {
        // Show dialog explaining why permission is needed
        new AlertDialog.Builder(activity)
                .setTitle(R.string.permission_needed)
                .setMessage(messageId)
                .setPositiveButton(R.string.ok, onClickListener)
                .create()
                .show();
    }
}
