package com.cs360.projectthree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddItemActivity extends AppCompatActivity {
    public static final String EXTRA_USER = "com.cs360.projectthree.user";

    private ApplicationDatabase mAppDb;

    private EditText itemNameEditText;
    private EditText itemQuantityEditText;
    private EditText itemUOMEditText;

    private String user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        // Get singleton
        mAppDb = ApplicationDatabase.getInstance(getApplicationContext());
        // Get views
        itemNameEditText = findViewById(R.id.enter_item_name);
        itemQuantityEditText = findViewById(R.id.enter_item_quantity);
        itemUOMEditText = findViewById(R.id.enter_uom);

        // Get user extra from intent
        Intent intent = getIntent();
        user = intent.getStringExtra(EXTRA_USER);
    }

    /*
     * Take values from all EditText fields to create a new item, and add
     * the item to the database. Then ListActivity is immediately started.
     */
    public void onAddClicked(View view) {
        String name = itemNameEditText.getText().toString();
        String quantity = itemQuantityEditText.getText().toString();
        String uom = itemUOMEditText.getText().toString();

        // Match empty String or whitespace
        String regex = "^$|\\s+";
        // Check if any feilds are empty
        if (name.matches(regex) || quantity.matches(regex) || uom.matches(regex)) {
            // Error if not all fields are filled
            Toast.makeText(this, getResources().getString(R.string.fill_all_fields), Toast.LENGTH_SHORT).show();
        }
        else {
            Item item = new Item();
            item.setName(name);
            item.setQuantity(Integer.parseInt(quantity));
            item.setUnitOfMeasure(uom);
            item.setUser(user);

            if(mAppDb.addItem(item)) {
                Toast.makeText(this, getResources().getString(R.string.new_item_added), Toast.LENGTH_SHORT).show();
            }

            // Start list activity and pass the user back
            Intent intent = new Intent(this, ListActivity.class);
            intent.putExtra(ListActivity.EXTRA_USER, user);
            startActivity(intent);
        }
    }
}